"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/api/barcodes";
exports.ids = ["pages/api/barcodes"];
exports.modules = {

/***/ "mongodb":
/*!**************************!*\
  !*** external "mongodb" ***!
  \**************************/
/***/ ((module) => {

module.exports = require("mongodb");

/***/ }),

/***/ "mongoose":
/*!***************************!*\
  !*** external "mongoose" ***!
  \***************************/
/***/ ((module) => {

module.exports = require("mongoose");

/***/ }),

/***/ "fs":
/*!*********************!*\
  !*** external "fs" ***!
  \*********************/
/***/ ((module) => {

module.exports = require("fs");

/***/ }),

/***/ "path":
/*!***********************!*\
  !*** external "path" ***!
  \***********************/
/***/ ((module) => {

module.exports = require("path");

/***/ }),

/***/ "(api)/./models/userModel.js":
/*!*****************************!*\
  !*** ./models/userModel.js ***!
  \*****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! mongoose */ \"mongoose\");\n/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);\n\nconst userSchema = new (mongoose__WEBPACK_IMPORTED_MODULE_0___default().Schema)({\n    userName: {\n        type: String,\n        required: true\n    },\n    password: {\n        type: String,\n        required: true\n    },\n    role: {\n        type: String,\n        default: \"user\"\n    },\n    root: {\n        type: Boolean,\n        default: false\n    },\n    balance: {\n        type: Number,\n        default: 0\n    }\n});\nlet User = (mongoose__WEBPACK_IMPORTED_MODULE_0___default().models.user) || mongoose__WEBPACK_IMPORTED_MODULE_0___default().model(\"user\", userSchema);\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (User);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9tb2RlbHMvdXNlck1vZGVsLmpzLmpzIiwibWFwcGluZ3MiOiI7Ozs7OztBQUErQjtBQUUvQixNQUFNQyxhQUFhLElBQUlELHdEQUFlLENBQUM7SUFDbkNHLFVBQVM7UUFDTEMsTUFBS0M7UUFDTEMsVUFBUyxJQUFJO0lBQ2pCO0lBQ0FDLFVBQVM7UUFDTEgsTUFBS0M7UUFDTEMsVUFBUyxJQUFJO0lBQ2pCO0lBQ0FFLE1BQUs7UUFDREosTUFBS0M7UUFDTEksU0FBUztJQUNiO0lBQ0FDLE1BQUs7UUFDRE4sTUFBTU87UUFDTkYsU0FBUSxLQUFLO0lBQ2pCO0lBQ0FHLFNBQVE7UUFDSlIsTUFBTVM7UUFDTkosU0FBUztJQUNiO0FBRUo7QUFFQSxJQUFJSyxPQUFPZCw2REFBb0IsSUFBSUEscURBQWMsQ0FBQyxRQUFRQztBQUMxRCxpRUFBZWEsSUFBSUEsRUFBQSIsInNvdXJjZXMiOlsid2VicGFjazovLy8uL21vZGVscy91c2VyTW9kZWwuanM/OTYxNyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgbW9uZ29vc2UgZnJvbSAnbW9uZ29vc2UnXHJcblxyXG5jb25zdCB1c2VyU2NoZW1hID0gbmV3IG1vbmdvb3NlLlNjaGVtYSh7XHJcbiAgICB1c2VyTmFtZTp7XHJcbiAgICAgICAgdHlwZTpTdHJpbmcsXHJcbiAgICAgICAgcmVxdWlyZWQ6dHJ1ZVxyXG4gICAgfSxcclxuICAgIHBhc3N3b3JkOntcclxuICAgICAgICB0eXBlOlN0cmluZyxcclxuICAgICAgICByZXF1aXJlZDp0cnVlXHJcbiAgICB9LFxyXG4gICAgcm9sZTp7XHJcbiAgICAgICAgdHlwZTpTdHJpbmcsXHJcbiAgICAgICAgZGVmYXVsdDogJ3VzZXInXHJcbiAgICB9LFxyXG4gICAgcm9vdDp7XHJcbiAgICAgICAgdHlwZTogQm9vbGVhbixcclxuICAgICAgICBkZWZhdWx0OmZhbHNlXHJcbiAgICB9LFxyXG4gICAgYmFsYW5jZTp7XHJcbiAgICAgICAgdHlwZTogTnVtYmVyLFxyXG4gICAgICAgIGRlZmF1bHQ6IDBcclxuICAgIH0sXHJcbiAgXHJcbn0pXHJcblxyXG5sZXQgVXNlciA9IG1vbmdvb3NlLm1vZGVscy51c2VyIHx8IG1vbmdvb3NlLm1vZGVsKCd1c2VyJywgdXNlclNjaGVtYSlcclxuZXhwb3J0IGRlZmF1bHQgVXNlclxyXG4iXSwibmFtZXMiOlsibW9uZ29vc2UiLCJ1c2VyU2NoZW1hIiwiU2NoZW1hIiwidXNlck5hbWUiLCJ0eXBlIiwiU3RyaW5nIiwicmVxdWlyZWQiLCJwYXNzd29yZCIsInJvbGUiLCJkZWZhdWx0Iiwicm9vdCIsIkJvb2xlYW4iLCJiYWxhbmNlIiwiTnVtYmVyIiwiVXNlciIsIm1vZGVscyIsInVzZXIiLCJtb2RlbCJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///(api)/./models/userModel.js\n");

/***/ }),

/***/ "(api)/./pages/api/barcodes.js":
/*!*******************************!*\
  !*** ./pages/api/barcodes.js ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ handler)\n/* harmony export */ });\n/* harmony import */ var _models_userModel__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../models/userModel */ \"(api)/./models/userModel.js\");\nconst MongoClient = (__webpack_require__(/*! mongodb */ \"mongodb\").MongoClient);\nconst uri = \"mongodb+srv://aditya4sure:RiseAbove@10bet.tld0wb0.mongodb.net/?retryWrites=true&w=majority\";\nconst client = new MongoClient(uri, {\n    useNewUrlParser: true\n});\n\nconst fs = __webpack_require__(/*! fs */ \"fs\");\nconst path = __webpack_require__(/*! path */ \"path\");\nasync function handler(req, res) {\n    try {\n        if (req.method === \"POST\") {\n            const { numberBets , drawTime , winningNumber , barcodeValue  } = req.body;\n            await client.connect();\n            const db = client.db(\"test\");\n            let winningAmount = 0;\n            if (numberBets.hasOwnProperty(winningNumber)) {\n                winningAmount = numberBets[winningNumber] * 11;\n            }\n            const result = await db.collection(\"barcodes\").insertOne({\n                numberBets: numberBets,\n                drawTime: drawTime,\n                winningNumber: winningNumber,\n                barcodeValue: barcodeValue,\n                winningAmount: winningAmount,\n                created: new Date()\n            });\n            const data = {\n                winningNumber: winningNumber,\n                numberBets: numberBets,\n                drawTime: drawTime,\n                barcodeValue: barcodeValue,\n                winningAmount: winningAmount\n            };\n            const filePath = path.join(process.cwd(), \"data\", \"barcodes.json\");\n            fs.writeFileSync(filePath, JSON.stringify(data));\n            res.status(200).json({\n                id: result.insertedId\n            });\n        } else if (req.method === \"GET\") {\n            await client.connect();\n            const db = client.db(\"test\");\n            const barcode = req.query.barcodeValue;\n            const { userName  } = req.query;\n            const user = await _models_userModel__WEBPACK_IMPORTED_MODULE_0__[\"default\"].findOne({\n                userName\n            });\n            if (!barcode) {\n                res.status(400).json({\n                    message: \"Barcode is required\"\n                });\n                return;\n            }\n            console.log(barcode);\n            const resultz = await db.collection(\"barcodes\").findOne({\n                barcodeValue: barcode\n            });\n            if (!resultz) {\n                res.status(404).json({\n                    message: \"Barcode not found\"\n                });\n                return;\n            }\n            const winningNumber = resultz.winningNumber;\n            const numberBets = resultz.numberBets;\n            let winningAmount = 0;\n            if (numberBets[winningNumber]) {\n                winningAmount = numberBets[winningNumber] * 11;\n            }\n            res.status(200).json({\n                winningAmount\n            });\n            if (!user) {\n                return res.status(404).json({\n                    error: \"User not found\"\n                });\n            }\n            user.balance += winningAmount;\n            await user.save();\n        } else {\n            res.status(405).json({\n                message: \"Method Not Allowed\"\n            });\n        }\n    } catch (error) {\n        console.log(error);\n        res.status(500).json({\n            message: \"Server Error\"\n        });\n    } finally{\n        await client.close();\n    }\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9wYWdlcy9hcGkvYmFyY29kZXMuanMuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7QUFBQSxNQUFNQSxjQUFjQywyREFBOEI7QUFDbEQsTUFBTUMsTUFBTUMsNEZBQXVCO0FBQ25DLE1BQU1HLFNBQVMsSUFBSU4sWUFBWUUsS0FBSztJQUFFSyxpQkFBaUIsSUFBSTtBQUFDO0FBQ2xCO0FBQzFDLE1BQU1FLEtBQUtSLG1CQUFPQSxDQUFDO0FBQ25CLE1BQU1TLE9BQU9ULG1CQUFPQSxDQUFDO0FBRU4sZUFBZVUsUUFBUUMsR0FBRyxFQUFFQyxHQUFHLEVBQUU7SUFDOUMsSUFBSTtRQUVGLElBQUlELElBQUlFLE1BQU0sS0FBSyxRQUFRO1lBQ3pCLE1BQU0sRUFBRUMsV0FBVSxFQUFFQyxTQUFRLEVBQUVDLGNBQWEsRUFBRUMsYUFBWSxFQUFFLEdBQUdOLElBQUlPLElBQUk7WUFHdEUsTUFBTWIsT0FBT2MsT0FBTztZQUNwQixNQUFNQyxLQUFLZixPQUFPZSxFQUFFLENBQUM7WUFDckIsSUFBSUMsZ0JBQWdCO1lBQ3BCLElBQUlQLFdBQVdRLGNBQWMsQ0FBQ04sZ0JBQWdCO2dCQUM1Q0ssZ0JBQWdCUCxVQUFVLENBQUNFLGNBQWMsR0FBRztZQUM5QyxDQUFDO1lBQ0QsTUFBTU8sU0FBUyxNQUFNSCxHQUFHSSxVQUFVLENBQUMsWUFBWUMsU0FBUyxDQUFDO2dCQUN2RFgsWUFBWUE7Z0JBQ1pDLFVBQVVBO2dCQUNWQyxlQUFlQTtnQkFDZkMsY0FBY0E7Z0JBQ2RJLGVBQWVBO2dCQUNmSyxTQUFTLElBQUlDO1lBQ2Y7WUFFQSxNQUFNQyxPQUFPO2dCQUNYWixlQUFlQTtnQkFDZkYsWUFBWUE7Z0JBQ1pDLFVBQVVBO2dCQUNWRSxjQUFjQTtnQkFDZEksZUFBZUE7WUFDakI7WUFDQSxNQUFNUSxXQUFXcEIsS0FBS3FCLElBQUksQ0FBQzVCLFFBQVE2QixHQUFHLElBQUksUUFBUTtZQUNsRHZCLEdBQUd3QixhQUFhLENBQUNILFVBQVVJLEtBQUtDLFNBQVMsQ0FBQ047WUFHMUNoQixJQUFJdUIsTUFBTSxDQUFDLEtBQUtDLElBQUksQ0FBQztnQkFBRUMsSUFBSWQsT0FBT2UsVUFBVTtZQUFDO1FBQy9DLE9BQU8sSUFBSTNCLElBQUlFLE1BQU0sS0FBSyxPQUFPO1lBQy9CLE1BQU1SLE9BQU9jLE9BQU87WUFDcEIsTUFBTUMsS0FBS2YsT0FBT2UsRUFBRSxDQUFDO1lBQ3JCLE1BQU1tQixVQUFVNUIsSUFBSTZCLEtBQUssQ0FBQ3ZCLFlBQVk7WUFDdEMsTUFBTSxFQUFFd0IsU0FBUSxFQUFFLEdBQUc5QixJQUFJNkIsS0FBSztZQUM5QixNQUFNRSxPQUFPLE1BQU1uQyxpRUFBYSxDQUFDO2dCQUFFa0M7WUFBUztZQUM1QyxJQUFJLENBQUNGLFNBQVM7Z0JBQ1ozQixJQUFJdUIsTUFBTSxDQUFDLEtBQUtDLElBQUksQ0FBQztvQkFBRVEsU0FBUztnQkFBc0I7Z0JBQ3REO1lBQ0YsQ0FBQztZQUFDQyxRQUFRQyxHQUFHLENBQUNQO1lBQ2QsTUFBTVEsVUFBVSxNQUFNM0IsR0FBR0ksVUFBVSxDQUFDLFlBQVltQixPQUFPLENBQUM7Z0JBQUUxQixjQUFjc0I7WUFBUTtZQUVoRixJQUFJLENBQUNRLFNBQVM7Z0JBQ1puQyxJQUFJdUIsTUFBTSxDQUFDLEtBQUtDLElBQUksQ0FBQztvQkFBRVEsU0FBUztnQkFBb0I7Z0JBQ3BEO1lBQ0YsQ0FBQztZQUVELE1BQU01QixnQkFBZ0IrQixRQUFRL0IsYUFBYTtZQUMzQyxNQUFNRixhQUFhaUMsUUFBUWpDLFVBQVU7WUFDckMsSUFBSU8sZ0JBQWdCO1lBRXBCLElBQUlQLFVBQVUsQ0FBQ0UsY0FBYyxFQUFFO2dCQUM3QkssZ0JBQWdCUCxVQUFVLENBQUNFLGNBQWMsR0FBRztZQUM5QyxDQUFDO1lBRURKLElBQUl1QixNQUFNLENBQUMsS0FBS0MsSUFBSSxDQUFDO2dCQUFFZjtZQUFjO1lBQ3JDLElBQUksQ0FBQ3FCLE1BQU07Z0JBQ1QsT0FBTzlCLElBQUl1QixNQUFNLENBQUMsS0FBS0MsSUFBSSxDQUFDO29CQUFFWSxPQUFPO2dCQUFpQjtZQUN4RCxDQUFDO1lBQ0ROLEtBQUtPLE9BQU8sSUFBSTVCO1lBQ2hCLE1BQU1xQixLQUFLUSxJQUFJO1FBQ2pCLE9BQU87WUFDTHRDLElBQUl1QixNQUFNLENBQUMsS0FBS0MsSUFBSSxDQUFDO2dCQUFFUSxTQUFTO1lBQXFCO1FBQ3ZELENBQUM7SUFFSCxFQUFFLE9BQU9JLE9BQU87UUFDZEgsUUFBUUMsR0FBRyxDQUFDRTtRQUNacEMsSUFBSXVCLE1BQU0sQ0FBQyxLQUFLQyxJQUFJLENBQUM7WUFBRVEsU0FBUztRQUFlO0lBQ2pELFNBQVU7UUFDUixNQUFNdkMsT0FBTzhDLEtBQUs7SUFDcEI7QUFDRixDQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vLy4vcGFnZXMvYXBpL2JhcmNvZGVzLmpzP2Q5M2EiXSwic291cmNlc0NvbnRlbnQiOlsiY29uc3QgTW9uZ29DbGllbnQgPSByZXF1aXJlKCdtb25nb2RiJykuTW9uZ29DbGllbnQ7XHJcbmNvbnN0IHVyaSA9IHByb2Nlc3MuZW52Lk1PTkdPREJfVVJJO1xyXG5jb25zdCBjbGllbnQgPSBuZXcgTW9uZ29DbGllbnQodXJpLCB7IHVzZU5ld1VybFBhcnNlcjogdHJ1ZSB9KTtcclxuaW1wb3J0IFVzZXJzIGZyb20gJy4uLy4uL21vZGVscy91c2VyTW9kZWwnXHJcbmNvbnN0IGZzID0gcmVxdWlyZSgnZnMnKTtcclxuY29uc3QgcGF0aCA9IHJlcXVpcmUoJ3BhdGgnKTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGFzeW5jIGZ1bmN0aW9uIGhhbmRsZXIocmVxLCByZXMpIHtcclxuICB0cnkge1xyXG5cclxuICAgIGlmIChyZXEubWV0aG9kID09PSAnUE9TVCcpIHtcclxuICAgICAgY29uc3QgeyBudW1iZXJCZXRzLCBkcmF3VGltZSwgd2lubmluZ051bWJlciwgYmFyY29kZVZhbHVlIH0gPSByZXEuYm9keVxyXG5cclxuXHJcbiAgICAgIGF3YWl0IGNsaWVudC5jb25uZWN0KCk7XHJcbiAgICAgIGNvbnN0IGRiID0gY2xpZW50LmRiKCd0ZXN0Jyk7XHJcbiAgICAgIGxldCB3aW5uaW5nQW1vdW50ID0gMDtcclxuICAgICAgaWYgKG51bWJlckJldHMuaGFzT3duUHJvcGVydHkod2lubmluZ051bWJlcikpIHtcclxuICAgICAgICB3aW5uaW5nQW1vdW50ID0gbnVtYmVyQmV0c1t3aW5uaW5nTnVtYmVyXSAqIDExO1xyXG4gICAgICB9XHJcbiAgICAgIGNvbnN0IHJlc3VsdCA9IGF3YWl0IGRiLmNvbGxlY3Rpb24oJ2JhcmNvZGVzJykuaW5zZXJ0T25lKHtcclxuICAgICAgICBudW1iZXJCZXRzOiBudW1iZXJCZXRzLFxyXG4gICAgICAgIGRyYXdUaW1lOiBkcmF3VGltZSxcclxuICAgICAgICB3aW5uaW5nTnVtYmVyOiB3aW5uaW5nTnVtYmVyLFxyXG4gICAgICAgIGJhcmNvZGVWYWx1ZTogYmFyY29kZVZhbHVlLFxyXG4gICAgICAgIHdpbm5pbmdBbW91bnQ6IHdpbm5pbmdBbW91bnQsXHJcbiAgICAgICAgY3JlYXRlZDogbmV3IERhdGUoKVxyXG4gICAgICB9KVxyXG5cclxuICAgICAgY29uc3QgZGF0YSA9IHtcclxuICAgICAgICB3aW5uaW5nTnVtYmVyOiB3aW5uaW5nTnVtYmVyLFxyXG4gICAgICAgIG51bWJlckJldHM6IG51bWJlckJldHMsXHJcbiAgICAgICAgZHJhd1RpbWU6IGRyYXdUaW1lLFxyXG4gICAgICAgIGJhcmNvZGVWYWx1ZTogYmFyY29kZVZhbHVlLFxyXG4gICAgICAgIHdpbm5pbmdBbW91bnQ6IHdpbm5pbmdBbW91bnRcclxuICAgICAgfTtcclxuICAgICAgY29uc3QgZmlsZVBhdGggPSBwYXRoLmpvaW4ocHJvY2Vzcy5jd2QoKSwgJ2RhdGEnLCAnYmFyY29kZXMuanNvbicpO1xyXG4gICAgICBmcy53cml0ZUZpbGVTeW5jKGZpbGVQYXRoLCBKU09OLnN0cmluZ2lmeShkYXRhKSk7XHJcblxyXG5cclxuICAgICAgcmVzLnN0YXR1cygyMDApLmpzb24oeyBpZDogcmVzdWx0Lmluc2VydGVkSWQgfSlcclxuICAgIH0gZWxzZSBpZiAocmVxLm1ldGhvZCA9PT0gJ0dFVCcpIHtcclxuICAgICAgYXdhaXQgY2xpZW50LmNvbm5lY3QoKTtcclxuICAgICAgY29uc3QgZGIgPSBjbGllbnQuZGIoJ3Rlc3QnKTtcclxuICAgICAgY29uc3QgYmFyY29kZSA9IHJlcS5xdWVyeS5iYXJjb2RlVmFsdWVcclxuICAgICAgY29uc3QgeyB1c2VyTmFtZSB9ID0gcmVxLnF1ZXJ5O1xyXG4gICAgICBjb25zdCB1c2VyID0gYXdhaXQgVXNlcnMuZmluZE9uZSh7IHVzZXJOYW1lIH0pO1xyXG4gICAgICBpZiAoIWJhcmNvZGUpIHtcclxuICAgICAgICByZXMuc3RhdHVzKDQwMCkuanNvbih7IG1lc3NhZ2U6ICdCYXJjb2RlIGlzIHJlcXVpcmVkJyB9KTtcclxuICAgICAgICByZXR1cm47XHJcbiAgICAgIH0gY29uc29sZS5sb2coYmFyY29kZSlcclxuICAgICAgY29uc3QgcmVzdWx0eiA9IGF3YWl0IGRiLmNvbGxlY3Rpb24oJ2JhcmNvZGVzJykuZmluZE9uZSh7IGJhcmNvZGVWYWx1ZTogYmFyY29kZSB9KTtcclxuXHJcbiAgICAgIGlmICghcmVzdWx0eikge1xyXG4gICAgICAgIHJlcy5zdGF0dXMoNDA0KS5qc29uKHsgbWVzc2FnZTogJ0JhcmNvZGUgbm90IGZvdW5kJyB9KTtcclxuICAgICAgICByZXR1cm47XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIGNvbnN0IHdpbm5pbmdOdW1iZXIgPSByZXN1bHR6Lndpbm5pbmdOdW1iZXI7XHJcbiAgICAgIGNvbnN0IG51bWJlckJldHMgPSByZXN1bHR6Lm51bWJlckJldHM7XHJcbiAgICAgIGxldCB3aW5uaW5nQW1vdW50ID0gMDtcclxuXHJcbiAgICAgIGlmIChudW1iZXJCZXRzW3dpbm5pbmdOdW1iZXJdKSB7XHJcbiAgICAgICAgd2lubmluZ0Ftb3VudCA9IG51bWJlckJldHNbd2lubmluZ051bWJlcl0gKiAxMTtcclxuICAgICAgfVxyXG5cclxuICAgICAgcmVzLnN0YXR1cygyMDApLmpzb24oeyB3aW5uaW5nQW1vdW50IH0pO1xyXG4gICAgICBpZiAoIXVzZXIpIHtcclxuICAgICAgICByZXR1cm4gcmVzLnN0YXR1cyg0MDQpLmpzb24oeyBlcnJvcjogJ1VzZXIgbm90IGZvdW5kJyB9KTtcclxuICAgICAgfVxyXG4gICAgICB1c2VyLmJhbGFuY2UgKz0gd2lubmluZ0Ftb3VudDtcclxuICAgICAgYXdhaXQgdXNlci5zYXZlKCk7XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICByZXMuc3RhdHVzKDQwNSkuanNvbih7IG1lc3NhZ2U6ICdNZXRob2QgTm90IEFsbG93ZWQnIH0pO1xyXG4gICAgfVxyXG5cclxuICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgY29uc29sZS5sb2coZXJyb3IpO1xyXG4gICAgcmVzLnN0YXR1cyg1MDApLmpzb24oeyBtZXNzYWdlOiAnU2VydmVyIEVycm9yJyB9KTtcclxuICB9IGZpbmFsbHkge1xyXG4gICAgYXdhaXQgY2xpZW50LmNsb3NlKCk7XHJcbiAgfVxyXG59Il0sIm5hbWVzIjpbIk1vbmdvQ2xpZW50IiwicmVxdWlyZSIsInVyaSIsInByb2Nlc3MiLCJlbnYiLCJNT05HT0RCX1VSSSIsImNsaWVudCIsInVzZU5ld1VybFBhcnNlciIsIlVzZXJzIiwiZnMiLCJwYXRoIiwiaGFuZGxlciIsInJlcSIsInJlcyIsIm1ldGhvZCIsIm51bWJlckJldHMiLCJkcmF3VGltZSIsIndpbm5pbmdOdW1iZXIiLCJiYXJjb2RlVmFsdWUiLCJib2R5IiwiY29ubmVjdCIsImRiIiwid2lubmluZ0Ftb3VudCIsImhhc093blByb3BlcnR5IiwicmVzdWx0IiwiY29sbGVjdGlvbiIsImluc2VydE9uZSIsImNyZWF0ZWQiLCJEYXRlIiwiZGF0YSIsImZpbGVQYXRoIiwiam9pbiIsImN3ZCIsIndyaXRlRmlsZVN5bmMiLCJKU09OIiwic3RyaW5naWZ5Iiwic3RhdHVzIiwianNvbiIsImlkIiwiaW5zZXJ0ZWRJZCIsImJhcmNvZGUiLCJxdWVyeSIsInVzZXJOYW1lIiwidXNlciIsImZpbmRPbmUiLCJtZXNzYWdlIiwiY29uc29sZSIsImxvZyIsInJlc3VsdHoiLCJlcnJvciIsImJhbGFuY2UiLCJzYXZlIiwiY2xvc2UiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///(api)/./pages/api/barcodes.js\n");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("(api)/./pages/api/barcodes.js"));
module.exports = __webpack_exports__;

})();