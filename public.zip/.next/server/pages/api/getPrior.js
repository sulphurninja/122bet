"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/api/getPrior";
exports.ids = ["pages/api/getPrior"];
exports.modules = {

/***/ "mongodb":
/*!**************************!*\
  !*** external "mongodb" ***!
  \**************************/
/***/ ((module) => {

module.exports = require("mongodb");

/***/ }),

/***/ "(api)/./pages/api/getPrior.js":
/*!*******************************!*\
  !*** ./pages/api/getPrior.js ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ handler)\n/* harmony export */ });\n/* harmony import */ var mongodb__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! mongodb */ \"mongodb\");\n/* harmony import */ var mongodb__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongodb__WEBPACK_IMPORTED_MODULE_0__);\n\nasync function handler(req, res) {\n    // Set up the connection URL and database name\n    const uri = \"mongodb+srv://aditya4sure:RiseAbove@10bet.tld0wb0.mongodb.net/?retryWrites=true&w=majority\";\n    const client = new mongodb__WEBPACK_IMPORTED_MODULE_0__.MongoClient(uri, {\n        useUnifiedTopology: true\n    });\n    const dbName = \"test\";\n    // Connect to the database\n    try {\n        await client.connect();\n        const db = client.db(dbName);\n        const collection = db.collection(\"fetchResults\");\n        // Extract the draw time from the request payload\n        const { drawTime  } = req.query;\n        // Get the current time\n        const now = new Date();\n        // If the current time is after the specified draw time, return an error\n        const nextToDraw = new Date(now.getFullYear(), now.getMonth(), now.getDate(), now.getHours(), now.getMinutes() + 1, 0, 0);\n        if (nextToDraw > new Date(drawTime)) {\n            return res.status(400).json({\n                message: \"Draw time has already passed\"\n            });\n        }\n        // Find the 10 most recent documents with the corresponding draw time\n        const results = await collection.find({\n            drawTime: {\n                $eq: drawTime\n            }\n        }).sort({\n            _id: -1\n        }).limit(10).toArray();\n        // If no documents are found, return an error\n        if (results.length === 0) {\n            return res.status(404).json({\n                message: `No winning numbers found for draw time: ${drawTime}`\n            });\n        }\n        // Return the winning numbers\n        const winningNumbers = results.map((result)=>result.winningNumber);\n        res.status(200).json({\n            winningNumbers\n        });\n    } catch (err) {\n        console.log(\"Error connecting to database:\", err);\n        res.status(500).json({\n            message: \"Error connecting to database\"\n        });\n    } finally{\n        await client.close();\n    }\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9wYWdlcy9hcGkvZ2V0UHJpb3IuanMuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7O0FBQXNDO0FBRXZCLGVBQWVDLFFBQVFDLEdBQUcsRUFBRUMsR0FBRyxFQUFFO0lBQzlDLDhDQUE4QztJQUM5QyxNQUFNQyxNQUFNQyw0RkFBdUI7SUFDbkMsTUFBTUcsU0FBUyxJQUFJUixnREFBV0EsQ0FBQ0ksS0FBSztRQUFFSyxvQkFBb0IsSUFBSTtJQUFDO0lBQy9ELE1BQU1DLFNBQVM7SUFFZiwwQkFBMEI7SUFDMUIsSUFBSTtRQUNGLE1BQU1GLE9BQU9HLE9BQU87UUFDcEIsTUFBTUMsS0FBS0osT0FBT0ksRUFBRSxDQUFDRjtRQUNyQixNQUFNRyxhQUFhRCxHQUFHQyxVQUFVLENBQUM7UUFFakMsaURBQWlEO1FBQ2pELE1BQU0sRUFBRUMsU0FBUSxFQUFFLEdBQUdaLElBQUlhLEtBQUs7UUFFOUIsdUJBQXVCO1FBQ3ZCLE1BQU1DLE1BQU0sSUFBSUM7UUFFaEIsd0VBQXdFO1FBQ3hFLE1BQU1DLGFBQWEsSUFBSUQsS0FDckJELElBQUlHLFdBQVcsSUFDZkgsSUFBSUksUUFBUSxJQUNaSixJQUFJSyxPQUFPLElBQ1hMLElBQUlNLFFBQVEsSUFDWk4sSUFBSU8sVUFBVSxLQUFLLEdBQ25CLEdBQ0E7UUFFRixJQUFJTCxhQUFhLElBQUlELEtBQUtILFdBQVc7WUFDbkMsT0FBT1gsSUFBSXFCLE1BQU0sQ0FBQyxLQUFLQyxJQUFJLENBQUM7Z0JBQUVDLFNBQVM7WUFBK0I7UUFDeEUsQ0FBQztRQUVELHFFQUFxRTtRQUNyRSxNQUFNQyxVQUFVLE1BQU1kLFdBQVdlLElBQUksQ0FBQztZQUFFZCxVQUFVO2dCQUFFZSxLQUFLZjtZQUFTO1FBQUUsR0FBR2dCLElBQUksQ0FBQztZQUFFQyxLQUFLLENBQUM7UUFBRSxHQUFHQyxLQUFLLENBQUMsSUFBSUMsT0FBTztRQUUxRyw2Q0FBNkM7UUFDN0MsSUFBSU4sUUFBUU8sTUFBTSxLQUFLLEdBQUc7WUFDeEIsT0FBTy9CLElBQUlxQixNQUFNLENBQUMsS0FBS0MsSUFBSSxDQUFDO2dCQUFFQyxTQUFTLENBQUMsd0NBQXdDLEVBQUVaLFNBQVMsQ0FBQztZQUFDO1FBQy9GLENBQUM7UUFFRCw2QkFBNkI7UUFDN0IsTUFBTXFCLGlCQUFpQlIsUUFBUVMsR0FBRyxDQUFDQyxDQUFBQSxTQUFVQSxPQUFPQyxhQUFhO1FBQ2pFbkMsSUFBSXFCLE1BQU0sQ0FBQyxLQUFLQyxJQUFJLENBQUM7WUFBRVU7UUFBZTtJQUV4QyxFQUFFLE9BQU9JLEtBQUs7UUFDWkMsUUFBUUMsR0FBRyxDQUFDLGlDQUFpQ0Y7UUFDN0NwQyxJQUFJcUIsTUFBTSxDQUFDLEtBQUtDLElBQUksQ0FBQztZQUFFQyxTQUFTO1FBQStCO0lBQ2pFLFNBQVU7UUFDUixNQUFNbEIsT0FBT2tDLEtBQUs7SUFDcEI7QUFDRixDQUFDIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vLy4vcGFnZXMvYXBpL2dldFByaW9yLmpzP2JhMWEiXSwic291cmNlc0NvbnRlbnQiOlsiaW1wb3J0IHsgTW9uZ29DbGllbnQgfSBmcm9tICdtb25nb2RiJztcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGFzeW5jIGZ1bmN0aW9uIGhhbmRsZXIocmVxLCByZXMpIHtcclxuICAvLyBTZXQgdXAgdGhlIGNvbm5lY3Rpb24gVVJMIGFuZCBkYXRhYmFzZSBuYW1lXHJcbiAgY29uc3QgdXJpID0gcHJvY2Vzcy5lbnYuTU9OR09EQl9VUkk7XHJcbiAgY29uc3QgY2xpZW50ID0gbmV3IE1vbmdvQ2xpZW50KHVyaSwgeyB1c2VVbmlmaWVkVG9wb2xvZ3k6IHRydWUgfSk7XHJcbiAgY29uc3QgZGJOYW1lID0gJ3Rlc3QnO1xyXG5cclxuICAvLyBDb25uZWN0IHRvIHRoZSBkYXRhYmFzZVxyXG4gIHRyeSB7XHJcbiAgICBhd2FpdCBjbGllbnQuY29ubmVjdCgpO1xyXG4gICAgY29uc3QgZGIgPSBjbGllbnQuZGIoZGJOYW1lKTtcclxuICAgIGNvbnN0IGNvbGxlY3Rpb24gPSBkYi5jb2xsZWN0aW9uKCdmZXRjaFJlc3VsdHMnKTtcclxuXHJcbiAgICAvLyBFeHRyYWN0IHRoZSBkcmF3IHRpbWUgZnJvbSB0aGUgcmVxdWVzdCBwYXlsb2FkXHJcbiAgICBjb25zdCB7IGRyYXdUaW1lIH0gPSByZXEucXVlcnk7XHJcblxyXG4gICAgLy8gR2V0IHRoZSBjdXJyZW50IHRpbWVcclxuICAgIGNvbnN0IG5vdyA9IG5ldyBEYXRlKCk7XHJcblxyXG4gICAgLy8gSWYgdGhlIGN1cnJlbnQgdGltZSBpcyBhZnRlciB0aGUgc3BlY2lmaWVkIGRyYXcgdGltZSwgcmV0dXJuIGFuIGVycm9yXHJcbiAgICBjb25zdCBuZXh0VG9EcmF3ID0gbmV3IERhdGUoXHJcbiAgICAgIG5vdy5nZXRGdWxsWWVhcigpLFxyXG4gICAgICBub3cuZ2V0TW9udGgoKSxcclxuICAgICAgbm93LmdldERhdGUoKSxcclxuICAgICAgbm93LmdldEhvdXJzKCksXHJcbiAgICAgIG5vdy5nZXRNaW51dGVzKCkgKyAxLFxyXG4gICAgICAwLFxyXG4gICAgICAwXHJcbiAgICApO1xyXG4gICAgaWYgKG5leHRUb0RyYXcgPiBuZXcgRGF0ZShkcmF3VGltZSkpIHtcclxuICAgICAgcmV0dXJuIHJlcy5zdGF0dXMoNDAwKS5qc29uKHsgbWVzc2FnZTogJ0RyYXcgdGltZSBoYXMgYWxyZWFkeSBwYXNzZWQnIH0pO1xyXG4gICAgfVxyXG5cclxuICAgIC8vIEZpbmQgdGhlIDEwIG1vc3QgcmVjZW50IGRvY3VtZW50cyB3aXRoIHRoZSBjb3JyZXNwb25kaW5nIGRyYXcgdGltZVxyXG4gICAgY29uc3QgcmVzdWx0cyA9IGF3YWl0IGNvbGxlY3Rpb24uZmluZCh7IGRyYXdUaW1lOiB7ICRlcTogZHJhd1RpbWUgfSB9KS5zb3J0KHsgX2lkOiAtMSB9KS5saW1pdCgxMCkudG9BcnJheSgpO1xyXG5cclxuICAgIC8vIElmIG5vIGRvY3VtZW50cyBhcmUgZm91bmQsIHJldHVybiBhbiBlcnJvclxyXG4gICAgaWYgKHJlc3VsdHMubGVuZ3RoID09PSAwKSB7XHJcbiAgICAgIHJldHVybiByZXMuc3RhdHVzKDQwNCkuanNvbih7IG1lc3NhZ2U6IGBObyB3aW5uaW5nIG51bWJlcnMgZm91bmQgZm9yIGRyYXcgdGltZTogJHtkcmF3VGltZX1gIH0pO1xyXG4gICAgfVxyXG5cclxuICAgIC8vIFJldHVybiB0aGUgd2lubmluZyBudW1iZXJzXHJcbiAgICBjb25zdCB3aW5uaW5nTnVtYmVycyA9IHJlc3VsdHMubWFwKHJlc3VsdCA9PiByZXN1bHQud2lubmluZ051bWJlcik7XHJcbiAgICByZXMuc3RhdHVzKDIwMCkuanNvbih7IHdpbm5pbmdOdW1iZXJzIH0pO1xyXG5cclxuICB9IGNhdGNoIChlcnIpIHtcclxuICAgIGNvbnNvbGUubG9nKCdFcnJvciBjb25uZWN0aW5nIHRvIGRhdGFiYXNlOicsIGVycik7XHJcbiAgICByZXMuc3RhdHVzKDUwMCkuanNvbih7IG1lc3NhZ2U6ICdFcnJvciBjb25uZWN0aW5nIHRvIGRhdGFiYXNlJyB9KTtcclxuICB9IGZpbmFsbHkge1xyXG4gICAgYXdhaXQgY2xpZW50LmNsb3NlKCk7XHJcbiAgfVxyXG59XHJcbiJdLCJuYW1lcyI6WyJNb25nb0NsaWVudCIsImhhbmRsZXIiLCJyZXEiLCJyZXMiLCJ1cmkiLCJwcm9jZXNzIiwiZW52IiwiTU9OR09EQl9VUkkiLCJjbGllbnQiLCJ1c2VVbmlmaWVkVG9wb2xvZ3kiLCJkYk5hbWUiLCJjb25uZWN0IiwiZGIiLCJjb2xsZWN0aW9uIiwiZHJhd1RpbWUiLCJxdWVyeSIsIm5vdyIsIkRhdGUiLCJuZXh0VG9EcmF3IiwiZ2V0RnVsbFllYXIiLCJnZXRNb250aCIsImdldERhdGUiLCJnZXRIb3VycyIsImdldE1pbnV0ZXMiLCJzdGF0dXMiLCJqc29uIiwibWVzc2FnZSIsInJlc3VsdHMiLCJmaW5kIiwiJGVxIiwic29ydCIsIl9pZCIsImxpbWl0IiwidG9BcnJheSIsImxlbmd0aCIsIndpbm5pbmdOdW1iZXJzIiwibWFwIiwicmVzdWx0Iiwid2lubmluZ051bWJlciIsImVyciIsImNvbnNvbGUiLCJsb2ciLCJjbG9zZSJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///(api)/./pages/api/getPrior.js\n");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("(api)/./pages/api/getPrior.js"));
module.exports = __webpack_exports__;

})();