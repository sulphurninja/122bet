"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/api/pushBets";
exports.ids = ["pages/api/pushBets"];
exports.modules = {

/***/ "mongodb":
/*!**************************!*\
  !*** external "mongodb" ***!
  \**************************/
/***/ ((module) => {

module.exports = require("mongodb");

/***/ }),

/***/ "mongoose":
/*!***************************!*\
  !*** external "mongoose" ***!
  \***************************/
/***/ ((module) => {

module.exports = require("mongoose");

/***/ }),

/***/ "(api)/./models/userModel.js":
/*!*****************************!*\
  !*** ./models/userModel.js ***!
  \*****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! mongoose */ \"mongoose\");\n/* harmony import */ var mongoose__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongoose__WEBPACK_IMPORTED_MODULE_0__);\n\nconst userSchema = new (mongoose__WEBPACK_IMPORTED_MODULE_0___default().Schema)({\n    userName: {\n        type: String,\n        required: true\n    },\n    password: {\n        type: String,\n        required: true\n    },\n    role: {\n        type: String,\n        default: \"user\"\n    },\n    root: {\n        type: Boolean,\n        default: false\n    },\n    balance: {\n        type: Number,\n        default: 0\n    }\n});\nlet User = (mongoose__WEBPACK_IMPORTED_MODULE_0___default().models.user) || mongoose__WEBPACK_IMPORTED_MODULE_0___default().model(\"user\", userSchema);\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (User);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9tb2RlbHMvdXNlck1vZGVsLmpzLmpzIiwibWFwcGluZ3MiOiI7Ozs7OztBQUErQjtBQUUvQixNQUFNQyxhQUFhLElBQUlELHdEQUFlLENBQUM7SUFDbkNHLFVBQVM7UUFDTEMsTUFBS0M7UUFDTEMsVUFBUyxJQUFJO0lBQ2pCO0lBQ0FDLFVBQVM7UUFDTEgsTUFBS0M7UUFDTEMsVUFBUyxJQUFJO0lBQ2pCO0lBQ0FFLE1BQUs7UUFDREosTUFBS0M7UUFDTEksU0FBUztJQUNiO0lBQ0FDLE1BQUs7UUFDRE4sTUFBTU87UUFDTkYsU0FBUSxLQUFLO0lBQ2pCO0lBQ0FHLFNBQVE7UUFDSlIsTUFBTVM7UUFDTkosU0FBUztJQUNiO0FBRUo7QUFFQSxJQUFJSyxPQUFPZCw2REFBb0IsSUFBSUEscURBQWMsQ0FBQyxRQUFRQztBQUMxRCxpRUFBZWEsSUFBSUEsRUFBQSIsInNvdXJjZXMiOlsid2VicGFjazovLy8uL21vZGVscy91c2VyTW9kZWwuanM/OTYxNyJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgbW9uZ29vc2UgZnJvbSAnbW9uZ29vc2UnXHJcblxyXG5jb25zdCB1c2VyU2NoZW1hID0gbmV3IG1vbmdvb3NlLlNjaGVtYSh7XHJcbiAgICB1c2VyTmFtZTp7XHJcbiAgICAgICAgdHlwZTpTdHJpbmcsXHJcbiAgICAgICAgcmVxdWlyZWQ6dHJ1ZVxyXG4gICAgfSxcclxuICAgIHBhc3N3b3JkOntcclxuICAgICAgICB0eXBlOlN0cmluZyxcclxuICAgICAgICByZXF1aXJlZDp0cnVlXHJcbiAgICB9LFxyXG4gICAgcm9sZTp7XHJcbiAgICAgICAgdHlwZTpTdHJpbmcsXHJcbiAgICAgICAgZGVmYXVsdDogJ3VzZXInXHJcbiAgICB9LFxyXG4gICAgcm9vdDp7XHJcbiAgICAgICAgdHlwZTogQm9vbGVhbixcclxuICAgICAgICBkZWZhdWx0OmZhbHNlXHJcbiAgICB9LFxyXG4gICAgYmFsYW5jZTp7XHJcbiAgICAgICAgdHlwZTogTnVtYmVyLFxyXG4gICAgICAgIGRlZmF1bHQ6IDBcclxuICAgIH0sXHJcbiAgXHJcbn0pXHJcblxyXG5sZXQgVXNlciA9IG1vbmdvb3NlLm1vZGVscy51c2VyIHx8IG1vbmdvb3NlLm1vZGVsKCd1c2VyJywgdXNlclNjaGVtYSlcclxuZXhwb3J0IGRlZmF1bHQgVXNlclxyXG4iXSwibmFtZXMiOlsibW9uZ29vc2UiLCJ1c2VyU2NoZW1hIiwiU2NoZW1hIiwidXNlck5hbWUiLCJ0eXBlIiwiU3RyaW5nIiwicmVxdWlyZWQiLCJwYXNzd29yZCIsInJvbGUiLCJkZWZhdWx0Iiwicm9vdCIsIkJvb2xlYW4iLCJiYWxhbmNlIiwiTnVtYmVyIiwiVXNlciIsIm1vZGVscyIsInVzZXIiLCJtb2RlbCJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///(api)/./models/userModel.js\n");

/***/ }),

/***/ "(api)/./pages/api/pushBets.js":
/*!*******************************!*\
  !*** ./pages/api/pushBets.js ***!
  \*******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ handler)\n/* harmony export */ });\n/* harmony import */ var _models_userModel__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ../../models/userModel */ \"(api)/./models/userModel.js\");\n/* harmony import */ var mongodb__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! mongodb */ \"mongodb\");\n/* harmony import */ var mongodb__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(mongodb__WEBPACK_IMPORTED_MODULE_1__);\n\n\nconst uri = \"mongodb+srv://aditya4sure:RiseAbove@10bet.tld0wb0.mongodb.net/?retryWrites=true&w=majority\";\nconst client = new mongodb__WEBPACK_IMPORTED_MODULE_1__.MongoClient(uri, {\n    useNewUrlParser: true,\n    useUnifiedTopology: true\n});\nasync function handler(req, res) {\n    try {\n        await client.connect();\n        const db = client.db(\"test\");\n        const collection = db.collection(\"bets\");\n        const { numberBets , totalAmount , userName  } = req.body;\n        const user = await _models_userModel__WEBPACK_IMPORTED_MODULE_0__[\"default\"].findOne({\n            userName\n        });\n        if (!user) {\n            return res.status(404).json({\n                error: \"User not found\"\n            });\n        }\n        if (user.balance < totalAmount) {\n            return res.status(400).json({\n                error: \"Insufficient balance\"\n            });\n        } else {\n            const result = await collection.insertOne({\n                numberBets,\n                totalAmount,\n                userName\n            });\n            user.balance -= totalAmount;\n            await user.save();\n            return res.status(200).json({\n                success: true,\n                data: result,\n                balance: user.balance\n            });\n        }\n    } catch (error) {\n        console.error(error);\n        res.status(500).json({\n            error: \"Unable to connect to database\"\n        });\n    } finally{\n        await client.close();\n    }\n}\n;\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9wYWdlcy9hcGkvcHVzaEJldHMuanMuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7OztBQUEyQztBQUNMO0FBRXRDLE1BQU1FLE1BQU1DLDRGQUF1QjtBQUNuQyxNQUFNRyxTQUFTLElBQUlMLGdEQUFXQSxDQUFDQyxLQUFLO0lBQ2xDSyxpQkFBaUIsSUFBSTtJQUNyQkMsb0JBQW9CLElBQUk7QUFDMUI7QUFFZSxlQUFlQyxRQUFRQyxHQUFHLEVBQUVDLEdBQUcsRUFBRTtJQUM5QyxJQUFJO1FBQ0YsTUFBTUwsT0FBT00sT0FBTztRQUNwQixNQUFNQyxLQUFLUCxPQUFPTyxFQUFFLENBQUM7UUFDckIsTUFBTUMsYUFBYUQsR0FBR0MsVUFBVSxDQUFDO1FBQ2pDLE1BQU0sRUFBRUMsV0FBVSxFQUFFQyxZQUFXLEVBQUVDLFNBQVEsRUFBRSxHQUFHUCxJQUFJUSxJQUFJO1FBR3RELE1BQU1DLE9BQU8sTUFBTW5CLGlFQUFhLENBQUM7WUFBRWlCO1FBQVM7UUFDNUMsSUFBSSxDQUFDRSxNQUFNO1lBQ1QsT0FBT1IsSUFBSVUsTUFBTSxDQUFDLEtBQUtDLElBQUksQ0FBQztnQkFBRUMsT0FBTztZQUFpQjtRQUN4RCxDQUFDO1FBRUQsSUFBSUosS0FBS0ssT0FBTyxHQUFHUixhQUFhO1lBQzlCLE9BQU9MLElBQUlVLE1BQU0sQ0FBQyxLQUFLQyxJQUFJLENBQUM7Z0JBQUVDLE9BQU87WUFBdUI7UUFDOUQsT0FDSztZQUNILE1BQU1FLFNBQVMsTUFBTVgsV0FBV1ksU0FBUyxDQUFDO2dCQUFFWDtnQkFBWUM7Z0JBQWFDO1lBQVM7WUFDOUVFLEtBQUtLLE9BQU8sSUFBSVI7WUFDaEIsTUFBTUcsS0FBS1EsSUFBSTtZQUVmLE9BQU9oQixJQUFJVSxNQUFNLENBQUMsS0FBS0MsSUFBSSxDQUFDO2dCQUFFTSxTQUFTLElBQUk7Z0JBQUVDLE1BQU1KO2dCQUFRRCxTQUFTTCxLQUFLSyxPQUFPO1lBQUM7UUFDbkYsQ0FBQztJQUNILEVBQUUsT0FBT0QsT0FBTztRQUNkTyxRQUFRUCxLQUFLLENBQUNBO1FBQ2RaLElBQUlVLE1BQU0sQ0FBQyxLQUFLQyxJQUFJLENBQUM7WUFBRUMsT0FBTztRQUFnQztJQUNoRSxTQUFVO1FBQ1IsTUFBTWpCLE9BQU95QixLQUFLO0lBQ3BCO0FBQ0YsQ0FBQyIsInNvdXJjZXMiOlsid2VicGFjazovLy8uL3BhZ2VzL2FwaS9wdXNoQmV0cy5qcz85YWQzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBVc2VycyBmcm9tICcuLi8uLi9tb2RlbHMvdXNlck1vZGVsJztcclxuaW1wb3J0IHsgTW9uZ29DbGllbnQgfSBmcm9tICdtb25nb2RiJztcclxuXHJcbmNvbnN0IHVyaSA9IHByb2Nlc3MuZW52Lk1PTkdPREJfVVJJO1xyXG5jb25zdCBjbGllbnQgPSBuZXcgTW9uZ29DbGllbnQodXJpLCB7XHJcbiAgdXNlTmV3VXJsUGFyc2VyOiB0cnVlLFxyXG4gIHVzZVVuaWZpZWRUb3BvbG9neTogdHJ1ZSxcclxufSk7XHJcblxyXG5leHBvcnQgZGVmYXVsdCBhc3luYyBmdW5jdGlvbiBoYW5kbGVyKHJlcSwgcmVzKSB7XHJcbiAgdHJ5IHtcclxuICAgIGF3YWl0IGNsaWVudC5jb25uZWN0KCk7XHJcbiAgICBjb25zdCBkYiA9IGNsaWVudC5kYigndGVzdCcpO1xyXG4gICAgY29uc3QgY29sbGVjdGlvbiA9IGRiLmNvbGxlY3Rpb24oJ2JldHMnKTtcclxuICAgIGNvbnN0IHsgbnVtYmVyQmV0cywgdG90YWxBbW91bnQsIHVzZXJOYW1lIH0gPSByZXEuYm9keTtcclxuICBcclxuXHJcbiAgICBjb25zdCB1c2VyID0gYXdhaXQgVXNlcnMuZmluZE9uZSh7IHVzZXJOYW1lIH0pO1xyXG4gICAgaWYgKCF1c2VyKSB7XHJcbiAgICAgIHJldHVybiByZXMuc3RhdHVzKDQwNCkuanNvbih7IGVycm9yOiAnVXNlciBub3QgZm91bmQnIH0pO1xyXG4gICAgfVxyXG5cclxuICAgIGlmICh1c2VyLmJhbGFuY2UgPCB0b3RhbEFtb3VudCkge1xyXG4gICAgICByZXR1cm4gcmVzLnN0YXR1cyg0MDApLmpzb24oeyBlcnJvcjogJ0luc3VmZmljaWVudCBiYWxhbmNlJyB9KTtcclxuICAgIH1cclxuICAgIGVsc2Uge1xyXG4gICAgICBjb25zdCByZXN1bHQgPSBhd2FpdCBjb2xsZWN0aW9uLmluc2VydE9uZSh7IG51bWJlckJldHMsIHRvdGFsQW1vdW50LCB1c2VyTmFtZSB9KTtcclxuICAgICAgdXNlci5iYWxhbmNlIC09IHRvdGFsQW1vdW50O1xyXG4gICAgICBhd2FpdCB1c2VyLnNhdmUoKTtcclxuXHJcbiAgICAgIHJldHVybiByZXMuc3RhdHVzKDIwMCkuanNvbih7IHN1Y2Nlc3M6IHRydWUsIGRhdGE6IHJlc3VsdCwgYmFsYW5jZTogdXNlci5iYWxhbmNlIH0pO1xyXG4gICAgfVxyXG4gIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICBjb25zb2xlLmVycm9yKGVycm9yKTtcclxuICAgIHJlcy5zdGF0dXMoNTAwKS5qc29uKHsgZXJyb3I6ICdVbmFibGUgdG8gY29ubmVjdCB0byBkYXRhYmFzZScgfSk7XHJcbiAgfSBmaW5hbGx5IHtcclxuICAgIGF3YWl0IGNsaWVudC5jbG9zZSgpO1xyXG4gIH1cclxufTtcclxuIl0sIm5hbWVzIjpbIlVzZXJzIiwiTW9uZ29DbGllbnQiLCJ1cmkiLCJwcm9jZXNzIiwiZW52IiwiTU9OR09EQl9VUkkiLCJjbGllbnQiLCJ1c2VOZXdVcmxQYXJzZXIiLCJ1c2VVbmlmaWVkVG9wb2xvZ3kiLCJoYW5kbGVyIiwicmVxIiwicmVzIiwiY29ubmVjdCIsImRiIiwiY29sbGVjdGlvbiIsIm51bWJlckJldHMiLCJ0b3RhbEFtb3VudCIsInVzZXJOYW1lIiwiYm9keSIsInVzZXIiLCJmaW5kT25lIiwic3RhdHVzIiwianNvbiIsImVycm9yIiwiYmFsYW5jZSIsInJlc3VsdCIsImluc2VydE9uZSIsInNhdmUiLCJzdWNjZXNzIiwiZGF0YSIsImNvbnNvbGUiLCJjbG9zZSJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///(api)/./pages/api/pushBets.js\n");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("(api)/./pages/api/pushBets.js"));
module.exports = __webpack_exports__;

})();