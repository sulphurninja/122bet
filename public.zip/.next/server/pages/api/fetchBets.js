"use strict";
/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/api/fetchBets";
exports.ids = ["pages/api/fetchBets"];
exports.modules = {

/***/ "mongodb":
/*!**************************!*\
  !*** external "mongodb" ***!
  \**************************/
/***/ ((module) => {

module.exports = require("mongodb");

/***/ }),

/***/ "(api)/./pages/api/fetchBets.js":
/*!********************************!*\
  !*** ./pages/api/fetchBets.js ***!
  \********************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ handler)\n/* harmony export */ });\n/* harmony import */ var mongodb__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! mongodb */ \"mongodb\");\n/* harmony import */ var mongodb__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(mongodb__WEBPACK_IMPORTED_MODULE_0__);\n\nconst uri = \"mongodb+srv://aditya4sure:RiseAbove@10bet.tld0wb0.mongodb.net/?retryWrites=true&w=majority\";\nconst client = new mongodb__WEBPACK_IMPORTED_MODULE_0__.MongoClient(uri, {\n    useNewUrlParser: true,\n    useUnifiedTopology: true\n});\nasync function handler(req, res) {\n    const { userName  } = req.query;\n    try {\n        await client.connect();\n        const db = client.db(\"test\");\n        const collection = db.collection(\"bets\");\n        let cursor = collection.find({\n            userName\n        });\n        let sortedCursor = cursor.sort({\n            _id: -1\n        });\n        let latestBet = await sortedCursor.next();\n        if (latestBet) {\n            res.status(200).json({\n                success: true,\n                data: latestBet.numberBets\n            });\n        } else {\n            res.status(404).json({\n                success: false,\n                message: `No bets found for user ${userName}`\n            });\n        }\n    } catch (error) {\n        console.error(error);\n        res.status(500).json({\n            error: \"Unable to connect to database\"\n        });\n    } finally{\n        await client.close();\n    }\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiKGFwaSkvLi9wYWdlcy9hcGkvZmV0Y2hCZXRzLmpzLmpzIiwibWFwcGluZ3MiOiI7Ozs7OztBQUFzQztBQUV0QyxNQUFNQyxNQUFNQyw0RkFBdUI7QUFDbkMsTUFBTUcsU0FBUyxJQUFJTCxnREFBV0EsQ0FBQ0MsS0FBSztJQUNsQ0ssaUJBQWlCLElBQUk7SUFDckJDLG9CQUFvQixJQUFJO0FBQzFCO0FBRWUsZUFBZUMsUUFBUUMsR0FBRyxFQUFFQyxHQUFHLEVBQUU7SUFDOUMsTUFBTSxFQUFFQyxTQUFRLEVBQUUsR0FBR0YsSUFBSUcsS0FBSztJQUU5QixJQUFJO1FBQ0YsTUFBTVAsT0FBT1EsT0FBTztRQUNwQixNQUFNQyxLQUFLVCxPQUFPUyxFQUFFLENBQUM7UUFDckIsTUFBTUMsYUFBYUQsR0FBR0MsVUFBVSxDQUFDO1FBQ2pDLElBQUlDLFNBQVNELFdBQVdFLElBQUksQ0FBQztZQUFFTjtRQUFTO1FBQ3hDLElBQUlPLGVBQWVGLE9BQU9HLElBQUksQ0FBQztZQUFFQyxLQUFLLENBQUM7UUFBRTtRQUN6QyxJQUFJQyxZQUFZLE1BQU1ILGFBQWFJLElBQUk7UUFFdkMsSUFBSUQsV0FBVztZQUNiWCxJQUFJYSxNQUFNLENBQUMsS0FBS0MsSUFBSSxDQUFDO2dCQUFFQyxTQUFTLElBQUk7Z0JBQUVDLE1BQU1MLFVBQVVNLFVBQVU7WUFBQztRQUNuRSxPQUFPO1lBQ0xqQixJQUFJYSxNQUFNLENBQUMsS0FBS0MsSUFBSSxDQUFDO2dCQUFFQyxTQUFTLEtBQUs7Z0JBQUVHLFNBQVMsQ0FBQyx1QkFBdUIsRUFBRWpCLFNBQVMsQ0FBQztZQUFDO1FBQ3ZGLENBQUM7SUFDSCxFQUFFLE9BQU9rQixPQUFPO1FBQ2RDLFFBQVFELEtBQUssQ0FBQ0E7UUFDZG5CLElBQUlhLE1BQU0sQ0FBQyxLQUFLQyxJQUFJLENBQUM7WUFBRUssT0FBTztRQUFnQztJQUNoRSxTQUFVO1FBQ1IsTUFBTXhCLE9BQU8wQixLQUFLO0lBQ3BCO0FBQ0YsQ0FBQyIsInNvdXJjZXMiOlsid2VicGFjazovLy8uL3BhZ2VzL2FwaS9mZXRjaEJldHMuanM/OGIyNSJdLCJzb3VyY2VzQ29udGVudCI6WyJpbXBvcnQgeyBNb25nb0NsaWVudCB9IGZyb20gJ21vbmdvZGInO1xyXG5cclxuY29uc3QgdXJpID0gcHJvY2Vzcy5lbnYuTU9OR09EQl9VUkk7XHJcbmNvbnN0IGNsaWVudCA9IG5ldyBNb25nb0NsaWVudCh1cmksIHtcclxuICB1c2VOZXdVcmxQYXJzZXI6IHRydWUsXHJcbiAgdXNlVW5pZmllZFRvcG9sb2d5OiB0cnVlLFxyXG59KTtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGFzeW5jIGZ1bmN0aW9uIGhhbmRsZXIocmVxLCByZXMpIHtcclxuICBjb25zdCB7IHVzZXJOYW1lIH0gPSByZXEucXVlcnk7XHJcblxyXG4gIHRyeSB7XHJcbiAgICBhd2FpdCBjbGllbnQuY29ubmVjdCgpO1xyXG4gICAgY29uc3QgZGIgPSBjbGllbnQuZGIoJ3Rlc3QnKTtcclxuICAgIGNvbnN0IGNvbGxlY3Rpb24gPSBkYi5jb2xsZWN0aW9uKCdiZXRzJyk7XHJcbiAgICBsZXQgY3Vyc29yID0gY29sbGVjdGlvbi5maW5kKHsgdXNlck5hbWUgfSk7XHJcbiAgICBsZXQgc29ydGVkQ3Vyc29yID0gY3Vyc29yLnNvcnQoeyBfaWQ6IC0xIH0pO1xyXG4gICAgbGV0IGxhdGVzdEJldCA9IGF3YWl0IHNvcnRlZEN1cnNvci5uZXh0KCk7XHJcblxyXG4gICAgaWYgKGxhdGVzdEJldCkge1xyXG4gICAgICByZXMuc3RhdHVzKDIwMCkuanNvbih7IHN1Y2Nlc3M6IHRydWUsIGRhdGE6IGxhdGVzdEJldC5udW1iZXJCZXRzIH0pO1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgcmVzLnN0YXR1cyg0MDQpLmpzb24oeyBzdWNjZXNzOiBmYWxzZSwgbWVzc2FnZTogYE5vIGJldHMgZm91bmQgZm9yIHVzZXIgJHt1c2VyTmFtZX1gIH0pO1xyXG4gICAgfVxyXG4gIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICBjb25zb2xlLmVycm9yKGVycm9yKTtcclxuICAgIHJlcy5zdGF0dXMoNTAwKS5qc29uKHsgZXJyb3I6ICdVbmFibGUgdG8gY29ubmVjdCB0byBkYXRhYmFzZScgfSk7XHJcbiAgfSBmaW5hbGx5IHtcclxuICAgIGF3YWl0IGNsaWVudC5jbG9zZSgpO1xyXG4gIH1cclxufVxyXG4iXSwibmFtZXMiOlsiTW9uZ29DbGllbnQiLCJ1cmkiLCJwcm9jZXNzIiwiZW52IiwiTU9OR09EQl9VUkkiLCJjbGllbnQiLCJ1c2VOZXdVcmxQYXJzZXIiLCJ1c2VVbmlmaWVkVG9wb2xvZ3kiLCJoYW5kbGVyIiwicmVxIiwicmVzIiwidXNlck5hbWUiLCJxdWVyeSIsImNvbm5lY3QiLCJkYiIsImNvbGxlY3Rpb24iLCJjdXJzb3IiLCJmaW5kIiwic29ydGVkQ3Vyc29yIiwic29ydCIsIl9pZCIsImxhdGVzdEJldCIsIm5leHQiLCJzdGF0dXMiLCJqc29uIiwic3VjY2VzcyIsImRhdGEiLCJudW1iZXJCZXRzIiwibWVzc2FnZSIsImVycm9yIiwiY29uc29sZSIsImNsb3NlIl0sInNvdXJjZVJvb3QiOiIifQ==\n//# sourceURL=webpack-internal:///(api)/./pages/api/fetchBets.js\n");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-api-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("(api)/./pages/api/fetchBets.js"));
module.exports = __webpack_exports__;

})();