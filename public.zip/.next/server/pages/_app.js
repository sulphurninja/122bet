/*
 * ATTENTION: An "eval-source-map" devtool has been used.
 * This devtool is neither made for production nor for readable output files.
 * It uses "eval()" calls to create a separate source file with attached SourceMaps in the browser devtools.
 * If you are trying to read the output file, select a different devtool (https://webpack.js.org/configuration/devtool/)
 * or disable the default devtool with "devtool: false".
 * If you are looking for production-ready output files, see mode: "production" (https://webpack.js.org/configuration/mode/).
 */
(() => {
var exports = {};
exports.id = "pages/_app";
exports.ids = ["pages/_app"];
exports.modules = {

/***/ "./pages/_app.jsx":
/*!************************!*\
  !*** ./pages/_app.jsx ***!
  \************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (/* binding */ App)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! ../styles/globals.css */ \"./styles/globals.css\");\n/* harmony import */ var _styles_globals_css__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_styles_globals_css__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _store_GlobalState__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ../store/GlobalState */ \"./store/GlobalState.js\");\n\n\n\nfunction App({ Component , pageProps  }) {\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(_store_GlobalState__WEBPACK_IMPORTED_MODULE_2__.DataProvider, {\n        children: /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(Component, {\n            ...pageProps\n        }, void 0, false, {\n            fileName: \"C:\\\\Users\\\\Aditya4Sure\\\\Desktop\\\\MAHBOOB BHAI\\\\10bet Merged\\\\10bet Merged\\\\pages\\\\_app.jsx\",\n            lineNumber: 7,\n            columnNumber: 3\n        }, this)\n    }, void 0, false, {\n        fileName: \"C:\\\\Users\\\\Aditya4Sure\\\\Desktop\\\\MAHBOOB BHAI\\\\10bet Merged\\\\10bet Merged\\\\pages\\\\_app.jsx\",\n        lineNumber: 6,\n        columnNumber: 5\n    }, this);\n}\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9wYWdlcy9fYXBwLmpzeC5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7O0FBQThCO0FBQ3FCO0FBRXBDLFNBQVNDLElBQUksRUFBRUMsVUFBUyxFQUFFQyxVQUFTLEVBQUUsRUFBRTtJQUNwRCxxQkFDRSw4REFBQ0gsNERBQVlBO2tCQUNmLDRFQUFDRTtZQUFXLEdBQUdDLFNBQVM7Ozs7Ozs7Ozs7O0FBRzFCLENBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vLi9wYWdlcy9fYXBwLmpzeD80Y2IzIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCAnLi4vc3R5bGVzL2dsb2JhbHMuY3NzJ1xuaW1wb3J0IHsgRGF0YVByb3ZpZGVyIH0gZnJvbSAnLi4vc3RvcmUvR2xvYmFsU3RhdGUnXG5cbmV4cG9ydCBkZWZhdWx0IGZ1bmN0aW9uIEFwcCh7IENvbXBvbmVudCwgcGFnZVByb3BzIH0pIHtcbiAgcmV0dXJuIChcbiAgICA8RGF0YVByb3ZpZGVyPlxuICA8Q29tcG9uZW50IHsuLi5wYWdlUHJvcHN9IC8+XG4gIDwvRGF0YVByb3ZpZGVyPlxuICApIFxufVxuIl0sIm5hbWVzIjpbIkRhdGFQcm92aWRlciIsIkFwcCIsIkNvbXBvbmVudCIsInBhZ2VQcm9wcyJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./pages/_app.jsx\n");

/***/ }),

/***/ "./store/Actions.js":
/*!**************************!*\
  !*** ./store/Actions.js ***!
  \**************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\nconst ACTIONS = {\n    AUTH: \"AUTH\"\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ACTIONS);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zdG9yZS9BY3Rpb25zLmpzLmpzIiwibWFwcGluZ3MiOiI7Ozs7QUFBQSxNQUFNQSxVQUFVO0lBQ1pDLE1BQU07QUFDVjtBQUVBLGlFQUFlRCxPQUFPQSxFQUFBIiwic291cmNlcyI6WyJ3ZWJwYWNrOi8vLy4vc3RvcmUvQWN0aW9ucy5qcz81Y2ViIl0sInNvdXJjZXNDb250ZW50IjpbImNvbnN0IEFDVElPTlMgPSB7XHJcbiAgICBBVVRIOiAnQVVUSCdcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQgQUNUSU9OUyJdLCJuYW1lcyI6WyJBQ1RJT05TIiwiQVVUSCJdLCJzb3VyY2VSb290IjoiIn0=\n//# sourceURL=webpack-internal:///./store/Actions.js\n");

/***/ }),

/***/ "./store/GlobalState.js":
/*!******************************!*\
  !*** ./store/GlobalState.js ***!
  \******************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"DataContext\": () => (/* binding */ DataContext),\n/* harmony export */   \"DataProvider\": () => (/* binding */ DataProvider)\n/* harmony export */ });\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! react/jsx-dev-runtime */ \"react/jsx-dev-runtime\");\n/* harmony import */ var react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__);\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(/*! react */ \"react\");\n/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);\n/* harmony import */ var _Reducers__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(/*! ./Reducers */ \"./store/Reducers.js\");\n/* harmony import */ var _utils_fetchData__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(/*! ../utils/fetchData */ \"./utils/fetchData.js\");\n\n\n\n\nconst DataContext = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.createContext)();\nconst DataProvider = ({ children  })=>{\n    const initialState = {\n        auth: {}\n    };\n    const [state, dispatch] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useReducer)(_Reducers__WEBPACK_IMPORTED_MODULE_2__[\"default\"], initialState);\n    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{\n        const firstLogin = localStorage.getItem(\"firstLogin\");\n        if (firstLogin) {\n            (0,_utils_fetchData__WEBPACK_IMPORTED_MODULE_3__.getData)(\"/auth/accessToken\").then((res)=>{\n                if (res.err) return localStorage.removeItem(\"firstLogin\");\n                dispatch({\n                    type: \"AUTH\",\n                    payload: {\n                        token: res.access_token,\n                        user: res.user\n                    }\n                });\n            });\n        }\n    }, []);\n    return /*#__PURE__*/ (0,react_jsx_dev_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxDEV)(DataContext.Provider, {\n        value: {\n            state,\n            dispatch\n        },\n        children: children\n    }, void 0, false, {\n        fileName: \"C:\\\\Users\\\\Aditya4Sure\\\\Desktop\\\\MAHBOOB BHAI\\\\10bet Merged\\\\10bet Merged\\\\store\\\\GlobalState.js\",\n        lineNumber: 30,\n        columnNumber: 9\n    }, undefined);\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zdG9yZS9HbG9iYWxTdGF0ZS5qcy5qcyIsIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7QUFBNkQ7QUFDM0I7QUFDVztBQUV0QyxNQUFNSyw0QkFBY0wsb0RBQWFBLEdBQUU7QUFFbkMsTUFBTU0sZUFBZSxDQUFDLEVBQUVDLFNBQVEsRUFBRSxHQUFLO0lBQzFDLE1BQU1DLGVBQWU7UUFBRUMsTUFBTSxDQUFDO0lBQUU7SUFDaEMsTUFBTSxDQUFDQyxPQUFPQyxTQUFTLEdBQUdWLGlEQUFVQSxDQUFDRSxpREFBUUEsRUFBRUs7SUFHL0NOLGdEQUFTQSxDQUFDLElBQUk7UUFDVixNQUFNVSxhQUFhQyxhQUFhQyxPQUFPLENBQUM7UUFDeEMsSUFBR0YsWUFBVztZQUNWUix5REFBT0EsQ0FBQyxxQkFBcUJXLElBQUksQ0FBQ0MsQ0FBQUEsTUFBTztnQkFDckMsSUFBR0EsSUFBSUMsR0FBRyxFQUFFLE9BQU9KLGFBQWFLLFVBQVUsQ0FBQztnQkFFM0NQLFNBQVM7b0JBQ0xRLE1BQU07b0JBQ05DLFNBQVE7d0JBQ0pDLE9BQU1MLElBQUlNLFlBQVk7d0JBQ3RCQyxNQUFNUCxJQUFJTyxJQUFJO29CQUNsQjtnQkFDSjtZQUNKO1FBQ0osQ0FBQztJQUNMLEdBQUcsRUFBRTtJQUVMLHFCQUNJLDhEQUFDbEIsWUFBWW1CLFFBQVE7UUFBQ0MsT0FBTztZQUFFZjtZQUFPQztRQUFTO2tCQUMxQ0o7Ozs7OztBQUdiLEVBQUMiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vLi9zdG9yZS9HbG9iYWxTdGF0ZS5qcz9lZTg1Il0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCB7IGNyZWF0ZUNvbnRleHQsIHVzZVJlZHVjZXIsIHVzZUVmZmVjdCB9IGZyb20gXCJyZWFjdFwiO1xyXG5pbXBvcnQgcmVkdWNlcnMgZnJvbSBcIi4vUmVkdWNlcnNcIjtcclxuaW1wb3J0IHsgZ2V0RGF0YSB9IGZyb20gXCIuLi91dGlscy9mZXRjaERhdGFcIjtcclxuXHJcbmV4cG9ydCBjb25zdCBEYXRhQ29udGV4dCA9IGNyZWF0ZUNvbnRleHQoKVxyXG5cclxuZXhwb3J0IGNvbnN0IERhdGFQcm92aWRlciA9ICh7IGNoaWxkcmVuIH0pID0+IHtcclxuICAgIGNvbnN0IGluaXRpYWxTdGF0ZSA9IHsgYXV0aDoge30gfVxyXG4gICAgY29uc3QgW3N0YXRlLCBkaXNwYXRjaF0gPSB1c2VSZWR1Y2VyKHJlZHVjZXJzLCBpbml0aWFsU3RhdGUpXHJcblxyXG5cclxuICAgIHVzZUVmZmVjdCgoKT0+e1xyXG4gICAgICAgIGNvbnN0IGZpcnN0TG9naW4gPSBsb2NhbFN0b3JhZ2UuZ2V0SXRlbSgnZmlyc3RMb2dpbicpO1xyXG4gICAgICAgIGlmKGZpcnN0TG9naW4pe1xyXG4gICAgICAgICAgICBnZXREYXRhKCcvYXV0aC9hY2Nlc3NUb2tlbicpLnRoZW4ocmVzID0+IHtcclxuICAgICAgICAgICAgICAgIGlmKHJlcy5lcnIpIHJldHVybiBsb2NhbFN0b3JhZ2UucmVtb3ZlSXRlbShcImZpcnN0TG9naW5cIilcclxuXHJcbiAgICAgICAgICAgICAgICBkaXNwYXRjaCh7XHJcbiAgICAgICAgICAgICAgICAgICAgdHlwZTogXCJBVVRIXCIsXHJcbiAgICAgICAgICAgICAgICAgICAgcGF5bG9hZDp7XHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHRva2VuOnJlcy5hY2Nlc3NfdG9rZW4sXHJcbiAgICAgICAgICAgICAgICAgICAgICAgIHVzZXI6IHJlcy51c2VyLFxyXG4gICAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgIH0pXHJcbiAgICAgICAgfVxyXG4gICAgfSwgW10pXHJcblxyXG4gICAgcmV0dXJuIChcclxuICAgICAgICA8RGF0YUNvbnRleHQuUHJvdmlkZXIgdmFsdWU9e3sgc3RhdGUsIGRpc3BhdGNoIH19PlxyXG4gICAgICAgICAgICB7Y2hpbGRyZW59XHJcbiAgICAgICAgPC9EYXRhQ29udGV4dC5Qcm92aWRlcj5cclxuICAgIClcclxufSJdLCJuYW1lcyI6WyJjcmVhdGVDb250ZXh0IiwidXNlUmVkdWNlciIsInVzZUVmZmVjdCIsInJlZHVjZXJzIiwiZ2V0RGF0YSIsIkRhdGFDb250ZXh0IiwiRGF0YVByb3ZpZGVyIiwiY2hpbGRyZW4iLCJpbml0aWFsU3RhdGUiLCJhdXRoIiwic3RhdGUiLCJkaXNwYXRjaCIsImZpcnN0TG9naW4iLCJsb2NhbFN0b3JhZ2UiLCJnZXRJdGVtIiwidGhlbiIsInJlcyIsImVyciIsInJlbW92ZUl0ZW0iLCJ0eXBlIiwicGF5bG9hZCIsInRva2VuIiwiYWNjZXNzX3Rva2VuIiwidXNlciIsIlByb3ZpZGVyIiwidmFsdWUiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./store/GlobalState.js\n");

/***/ }),

/***/ "./store/Reducers.js":
/*!***************************!*\
  !*** ./store/Reducers.js ***!
  \***************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"default\": () => (__WEBPACK_DEFAULT_EXPORT__)\n/* harmony export */ });\n/* harmony import */ var _Actions__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(/*! ./Actions */ \"./store/Actions.js\");\n\nconst reducers = (state, action)=>{\n    switch(action.type){\n        case _Actions__WEBPACK_IMPORTED_MODULE_0__[\"default\"].AUTH:\n            return {\n                ...state,\n                auth: action.payload\n            };\n        default:\n            return state;\n    }\n};\n/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (reducers);\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi9zdG9yZS9SZWR1Y2Vycy5qcy5qcyIsIm1hcHBpbmdzIjoiOzs7OztBQUErQjtBQUUvQixNQUFNQyxXQUFXLENBQUNDLE9BQU9DLFNBQVU7SUFDL0IsT0FBT0EsT0FBT0MsSUFBSTtRQUNkLEtBQUtKLHFEQUFZO1lBQ2IsT0FBTTtnQkFDRixHQUFHRSxLQUFLO2dCQUNSSSxNQUFNSCxPQUFPSSxPQUFPO1lBQ3hCO1FBQ0E7WUFDSSxPQUFPTDtJQUNuQjtBQUNKO0FBRUEsaUVBQWVELFFBQVFBLEVBQUEiLCJzb3VyY2VzIjpbIndlYnBhY2s6Ly8vLi9zdG9yZS9SZWR1Y2Vycy5qcz8zYTNiIl0sInNvdXJjZXNDb250ZW50IjpbImltcG9ydCBBQ1RJT05TIGZyb20gJy4vQWN0aW9ucydcclxuXHJcbmNvbnN0IHJlZHVjZXJzID0gKHN0YXRlLCBhY3Rpb24pID0+e1xyXG4gICAgc3dpdGNoKGFjdGlvbi50eXBlKXtcclxuICAgICAgICBjYXNlIEFDVElPTlMuQVVUSDpcclxuICAgICAgICAgICAgcmV0dXJue1xyXG4gICAgICAgICAgICAgICAgLi4uc3RhdGUsXHJcbiAgICAgICAgICAgICAgICBhdXRoOiBhY3Rpb24ucGF5bG9hZFxyXG4gICAgICAgICAgICB9O1xyXG4gICAgICAgICAgICBkZWZhdWx0OlxyXG4gICAgICAgICAgICAgICAgcmV0dXJuIHN0YXRlO1xyXG4gICAgfVxyXG59XHJcblxyXG5leHBvcnQgZGVmYXVsdCByZWR1Y2VycyJdLCJuYW1lcyI6WyJBQ1RJT05TIiwicmVkdWNlcnMiLCJzdGF0ZSIsImFjdGlvbiIsInR5cGUiLCJBVVRIIiwiYXV0aCIsInBheWxvYWQiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./store/Reducers.js\n");

/***/ }),

/***/ "./utils/fetchData.js":
/*!****************************!*\
  !*** ./utils/fetchData.js ***!
  \****************************/
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
eval("__webpack_require__.r(__webpack_exports__);\n/* harmony export */ __webpack_require__.d(__webpack_exports__, {\n/* harmony export */   \"deleteData\": () => (/* binding */ deleteData),\n/* harmony export */   \"getData\": () => (/* binding */ getData),\n/* harmony export */   \"patchData\": () => (/* binding */ patchData),\n/* harmony export */   \"postData\": () => (/* binding */ postData),\n/* harmony export */   \"putData\": () => (/* binding */ putData)\n/* harmony export */ });\nconst baseUrl = \"http://localhost:3000\";\nconst getData = async (url, token)=>{\n    const res = await fetch(`${baseUrl}/api/${url}`, {\n        method: \"GET\",\n        headers: {\n            \"Authorization\": token\n        }\n    });\n    const data = await res.json();\n    return data;\n};\nconst postData = async (url, post, token)=>{\n    const res = await fetch(`${baseUrl}/api/${url}`, {\n        method: \"POST\",\n        headers: {\n            \"Content-Type\": \"application/json\",\n            \"Authorization\": token\n        },\n        body: JSON.stringify(post)\n    });\n    const data = await res.json();\n    return data;\n};\nconst putData = async (url, post, token)=>{\n    const res = await fetch(`${baseUrl}/api/${url}`, {\n        method: \"PUT\",\n        headers: {\n            \"Content-Type\": \"application/json\",\n            \"Authorization\": token\n        },\n        body: JSON.stringify(post)\n    });\n    const data = await res.json();\n    return data;\n};\nconst patchData = async (url, post, token)=>{\n    const res = await fetch(`${baseUrl}/api/${url}`, {\n        method: \"PATCH\",\n        headers: {\n            \"Content-Type\": \"application/json\",\n            \"Authorization\": token\n        },\n        body: JSON.stringify(post)\n    });\n    const data = await res.json();\n    return data;\n};\nconst deleteData = async (url, token)=>{\n    const res = await fetch(`${baseUrl}/api/${url}`, {\n        method: \"DELETE\",\n        headers: {\n            \"Content-Type\": \"application/json\",\n            \"Authorization\": token\n        }\n    });\n    const data = await res.json();\n    return data;\n};\n//# sourceURL=[module]\n//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiLi91dGlscy9mZXRjaERhdGEuanMuanMiLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7QUFBQSxNQUFNQSxVQUFVQyx1QkFBb0I7QUFFN0IsTUFBTUcsVUFBVSxPQUFPQyxLQUFLQyxRQUFTO0lBQ3hDLE1BQU1DLE1BQU0sTUFBTUMsTUFBTSxDQUFDLEVBQUVSLFFBQVEsS0FBSyxFQUFFSyxJQUFJLENBQUMsRUFBRTtRQUM3Q0ksUUFBUTtRQUNSQyxTQUFTO1lBQ0wsaUJBQWlCSjtRQUNyQjtJQUNKO0lBQ0EsTUFBTUssT0FBTyxNQUFNSixJQUFJSyxJQUFJO0lBQzNCLE9BQU9EO0FBQ1gsRUFBQztBQUVNLE1BQU1FLFdBQVcsT0FBT1IsS0FBS1MsTUFBTVIsUUFBUztJQUMvQyxNQUFNQyxNQUFNLE1BQU1DLE1BQU0sQ0FBQyxFQUFFUixRQUFRLEtBQUssRUFBRUssSUFBSSxDQUFDLEVBQUU7UUFDN0NJLFFBQVE7UUFDUkMsU0FBUztZQUNMLGdCQUFlO1lBQ2YsaUJBQWlCSjtRQUNyQjtRQUNBUyxNQUFNQyxLQUFLQyxTQUFTLENBQUNIO0lBQ3pCO0lBQ0EsTUFBTUgsT0FBTyxNQUFNSixJQUFJSyxJQUFJO0lBQzNCLE9BQU9EO0FBQ1gsRUFBQztBQUVNLE1BQU1PLFVBQVUsT0FBT2IsS0FBS1MsTUFBTVIsUUFBUztJQUM5QyxNQUFNQyxNQUFNLE1BQU1DLE1BQU0sQ0FBQyxFQUFFUixRQUFRLEtBQUssRUFBRUssSUFBSSxDQUFDLEVBQUU7UUFDN0NJLFFBQVE7UUFDUkMsU0FBUztZQUNMLGdCQUFlO1lBQ2YsaUJBQWlCSjtRQUNyQjtRQUNBUyxNQUFNQyxLQUFLQyxTQUFTLENBQUNIO0lBQ3pCO0lBQ0EsTUFBTUgsT0FBTyxNQUFNSixJQUFJSyxJQUFJO0lBQzNCLE9BQU9EO0FBQ1gsRUFBQztBQUVNLE1BQU1RLFlBQVksT0FBT2QsS0FBS1MsTUFBTVIsUUFBUztJQUNoRCxNQUFNQyxNQUFNLE1BQU1DLE1BQU0sQ0FBQyxFQUFFUixRQUFRLEtBQUssRUFBRUssSUFBSSxDQUFDLEVBQUU7UUFDN0NJLFFBQVE7UUFDUkMsU0FBUztZQUNMLGdCQUFlO1lBQ2YsaUJBQWlCSjtRQUNyQjtRQUNBUyxNQUFNQyxLQUFLQyxTQUFTLENBQUNIO0lBQ3pCO0lBQ0EsTUFBTUgsT0FBTyxNQUFNSixJQUFJSyxJQUFJO0lBQzNCLE9BQU9EO0FBQ1gsRUFBQztBQUNNLE1BQU1TLGFBQWEsT0FBT2YsS0FBS0MsUUFBUztJQUMzQyxNQUFNQyxNQUFNLE1BQU1DLE1BQU0sQ0FBQyxFQUFFUixRQUFRLEtBQUssRUFBRUssSUFBSSxDQUFDLEVBQUU7UUFDN0NJLFFBQVE7UUFDUkMsU0FBUztZQUNMLGdCQUFlO1lBQ2YsaUJBQWlCSjtRQUNyQjtJQUNKO0lBQ0EsTUFBTUssT0FBTyxNQUFNSixJQUFJSyxJQUFJO0lBQzNCLE9BQU9EO0FBQ1gsRUFBQyIsInNvdXJjZXMiOlsid2VicGFjazovLy8uL3V0aWxzL2ZldGNoRGF0YS5qcz84NGM0Il0sInNvdXJjZXNDb250ZW50IjpbImNvbnN0IGJhc2VVcmwgPSBwcm9jZXNzLmVudi5CQVNFX1VSTFxyXG5cclxuZXhwb3J0IGNvbnN0IGdldERhdGEgPSBhc3luYyAodXJsLCB0b2tlbikgPT57XHJcbiAgICBjb25zdCByZXMgPSBhd2FpdCBmZXRjaChgJHtiYXNlVXJsfS9hcGkvJHt1cmx9YCwge1xyXG4gICAgICAgIG1ldGhvZDogJ0dFVCcsXHJcbiAgICAgICAgaGVhZGVyczoge1xyXG4gICAgICAgICAgICAnQXV0aG9yaXphdGlvbic6IHRva2VuIFxyXG4gICAgICAgIH1cclxuICAgIH0pXHJcbiAgICBjb25zdCBkYXRhID0gYXdhaXQgcmVzLmpzb24oKVxyXG4gICAgcmV0dXJuIGRhdGFcclxufVxyXG5cclxuZXhwb3J0IGNvbnN0IHBvc3REYXRhID0gYXN5bmMgKHVybCwgcG9zdCwgdG9rZW4pID0+e1xyXG4gICAgY29uc3QgcmVzID0gYXdhaXQgZmV0Y2goYCR7YmFzZVVybH0vYXBpLyR7dXJsfWAsIHtcclxuICAgICAgICBtZXRob2Q6ICdQT1NUJyxcclxuICAgICAgICBoZWFkZXJzOiB7XHJcbiAgICAgICAgICAgICdDb250ZW50LVR5cGUnOidhcHBsaWNhdGlvbi9qc29uJyxcclxuICAgICAgICAgICAgJ0F1dGhvcml6YXRpb24nOiB0b2tlbiBcclxuICAgICAgICB9LFxyXG4gICAgICAgIGJvZHk6IEpTT04uc3RyaW5naWZ5KHBvc3QpXHJcbiAgICB9KVxyXG4gICAgY29uc3QgZGF0YSA9IGF3YWl0IHJlcy5qc29uKClcclxuICAgIHJldHVybiBkYXRhXHJcbn1cclxuXHJcbmV4cG9ydCBjb25zdCBwdXREYXRhID0gYXN5bmMgKHVybCwgcG9zdCwgdG9rZW4pID0+e1xyXG4gICAgY29uc3QgcmVzID0gYXdhaXQgZmV0Y2goYCR7YmFzZVVybH0vYXBpLyR7dXJsfWAsIHtcclxuICAgICAgICBtZXRob2Q6ICdQVVQnLFxyXG4gICAgICAgIGhlYWRlcnM6IHtcclxuICAgICAgICAgICAgJ0NvbnRlbnQtVHlwZSc6J2FwcGxpY2F0aW9uL2pzb24nLFxyXG4gICAgICAgICAgICAnQXV0aG9yaXphdGlvbic6IHRva2VuIFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkocG9zdClcclxuICAgIH0pXHJcbiAgICBjb25zdCBkYXRhID0gYXdhaXQgcmVzLmpzb24oKVxyXG4gICAgcmV0dXJuIGRhdGFcclxufVxyXG5cclxuZXhwb3J0IGNvbnN0IHBhdGNoRGF0YSA9IGFzeW5jICh1cmwsIHBvc3QsIHRva2VuKSA9PntcclxuICAgIGNvbnN0IHJlcyA9IGF3YWl0IGZldGNoKGAke2Jhc2VVcmx9L2FwaS8ke3VybH1gLCB7XHJcbiAgICAgICAgbWV0aG9kOiAnUEFUQ0gnLFxyXG4gICAgICAgIGhlYWRlcnM6IHtcclxuICAgICAgICAgICAgJ0NvbnRlbnQtVHlwZSc6J2FwcGxpY2F0aW9uL2pzb24nLFxyXG4gICAgICAgICAgICAnQXV0aG9yaXphdGlvbic6IHRva2VuIFxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgYm9keTogSlNPTi5zdHJpbmdpZnkocG9zdClcclxuICAgIH0pXHJcbiAgICBjb25zdCBkYXRhID0gYXdhaXQgcmVzLmpzb24oKVxyXG4gICAgcmV0dXJuIGRhdGFcclxufVxyXG5leHBvcnQgY29uc3QgZGVsZXRlRGF0YSA9IGFzeW5jICh1cmwsIHRva2VuKSA9PntcclxuICAgIGNvbnN0IHJlcyA9IGF3YWl0IGZldGNoKGAke2Jhc2VVcmx9L2FwaS8ke3VybH1gLCB7XHJcbiAgICAgICAgbWV0aG9kOiAnREVMRVRFJyxcclxuICAgICAgICBoZWFkZXJzOiB7XHJcbiAgICAgICAgICAgICdDb250ZW50LVR5cGUnOidhcHBsaWNhdGlvbi9qc29uJyxcclxuICAgICAgICAgICAgJ0F1dGhvcml6YXRpb24nOiB0b2tlbiBcclxuICAgICAgICB9LFxyXG4gICAgfSlcclxuICAgIGNvbnN0IGRhdGEgPSBhd2FpdCByZXMuanNvbigpXHJcbiAgICByZXR1cm4gZGF0YVxyXG59Il0sIm5hbWVzIjpbImJhc2VVcmwiLCJwcm9jZXNzIiwiZW52IiwiQkFTRV9VUkwiLCJnZXREYXRhIiwidXJsIiwidG9rZW4iLCJyZXMiLCJmZXRjaCIsIm1ldGhvZCIsImhlYWRlcnMiLCJkYXRhIiwianNvbiIsInBvc3REYXRhIiwicG9zdCIsImJvZHkiLCJKU09OIiwic3RyaW5naWZ5IiwicHV0RGF0YSIsInBhdGNoRGF0YSIsImRlbGV0ZURhdGEiXSwic291cmNlUm9vdCI6IiJ9\n//# sourceURL=webpack-internal:///./utils/fetchData.js\n");

/***/ }),

/***/ "./styles/globals.css":
/*!****************************!*\
  !*** ./styles/globals.css ***!
  \****************************/
/***/ (() => {



/***/ }),

/***/ "react":
/*!************************!*\
  !*** external "react" ***!
  \************************/
/***/ ((module) => {

"use strict";
module.exports = require("react");

/***/ }),

/***/ "react/jsx-dev-runtime":
/*!****************************************!*\
  !*** external "react/jsx-dev-runtime" ***!
  \****************************************/
/***/ ((module) => {

"use strict";
module.exports = require("react/jsx-dev-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = (__webpack_exec__("./pages/_app.jsx"));
module.exports = __webpack_exports__;

})();