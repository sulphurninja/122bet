import React from 'react'
import Easylogout from '../components/Easylogout'

const Logout = () => {
  return (
    <div>
      <Easylogout />
    </div>
  )
}

export default Logout




