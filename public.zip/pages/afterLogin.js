import React from 'react'
import Easylogout from '../components/Easylogout'

function afterLogin() {
    return (
        <body>
            <div >
                <Easylogout />
            </div>

        </body>

    )
}

export default afterLogin